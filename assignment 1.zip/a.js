
//Q1. Program to find particular character in a string //
let str="Javascript"
console.log("1: To find particular character in the string :" + str);
console.log(str.indexOf("t"));

//Q2. Program to convert minutes to seconds
console.log("2: ");
let min=1
let sec=min*60
console.log("minutes =" + min);
console.log("Converting minutes into seconds : " + "Total seconds = " + sec );

//Q3. Program to search element in a array of strings
console.log("3: ");
let arr1=[1,2,3]
let arr2=["c", "c++", "js"]
console.log(arr1.indexOf(2));
console.log(arr2.indexOf("js"));

//Q4. Program to display only elements containing 'a' in the term of array
console.log("4: ");
let array=["cap", "ball", "element"]
console.log(array);
let s=array.filter(function (e){
if(e.indexOf("a"))
{
  return e
}
});
console.log(s);


  //Q5. Print an array in reverse order
  console.log("5: ");
 let arr=["apple", "mango", "pineapple", "strawberry"]
  console.log(arr);
  //console.log(arr.reverse());
  // or
  for(let i=(arr.length-1);i>=0;i--)
  {
    console.log(arr[i]);
  }
